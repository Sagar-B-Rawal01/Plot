%% Example script to visualize the aircraft simulation data
% Add the path of the aircraft_3d_animation function
addpath('../src/');
% path of the *.mat file containing the 3d model information
model_info_file = '../3d_models/t.mat';
% Load the simulation data
% load('scissors_maneuver.mat')
% load('breakaway_maneuver.mat')
% load('split_s_maneuver.mat')
load('departure.mat')
% define the reproduction speed factor
speedx = 10; 
% Do you want to save the animation in a mp4 file? (0.No, 1.Yes)
isave_movie = 0;
% Movie file name
movie_file_name = '';

% -------------------------------------------------------------------------
% The frame sample time shall be higher than 0.02 seconds to be able to 
% update the figure (CPU/GPU constraints)
frame_sample_time = max(0.02, tout(2)-tout(1));
% Resample the time vector to modify the reproduction speed
t_new   = tout(1):frame_sample_time*(speedx):tout(end);
% Resample the recorded data
act     = interp1(tout, act, t_new','linear');
stick   = interp1(tout, stick, t_new','linear');
y_new   = interp1(tout, yout, t_new','linear');
% We have to be careful with angles with ranges
y_new(:, 7)  = atan2(interp1(tout, sin(yout(:, 7)), t_new','linear'), interp1(tout, cos(yout(:, 7)), t_new','linear')) * 180 / pi;
y_new(:, 8)  = atan2(interp1(tout, sin(yout(:, 8)), t_new','linear'), interp1(tout, cos(yout(:, 8)), t_new','linear')) * 180 / pi;
y_new(:, 9)  = atan2(interp1(tout, sin(yout(:, 9)), t_new','linear'), interp1(tout, cos(yout(:, 9)), t_new','linear')) * 180 / pi;
% Assign the data
heading_deg           =  y_new(:, 7);
pitch_deg             =  y_new(:, 8);
bank_deg              =  y_new(:, 9);
roll_command          = -stick(:, 2);
pitch_command         = -stick(:, 1);
angle_of_attack_deg   =  y_new(:, 2) * 180 / pi;
angle_of_sideslip_deg =  y_new(:, 3) * 180 / pi;
fligh_path_angle_deg  =  y_new(:, 22) * 180 / pi;
mach                  =  y_new(:, 21);
altitude_ft           = -y_new(:, 12);
nz_g                  =  y_new(:, 19);
% Flight control surfaces
le     = act(:, 9);
dr     = act(:, 8);
df1    = act(:, 6);
df2    = act(:, 5);
df3    = act(:, 4);
df4    = act(:, 3);
dfp    = 0.5 * (act(:, 1) + act(:, 2));
lg=90*ones(size(dfp))
% Control array assignation
% (modify the order according to your particular 3D model)
controls_deflection_deg = [dfp(:), dfp(:),dfp(:), dfp(:), le(:), le(:), dr(:), 0.5*(df1(:)+df2(:)), 0.5*(df3(:)+df4(:)) 0.5*(df1(:)+df2(:)), 0.5*(df3(:)+df4(:)) lg lg];

 rudder_cmd=  dr;
 throttle_cmd=130*rand(size(dr));
velocity=mach;
flags=[randi([0,1],size(velocity)),randi([0,1],size(velocity)),randi([0,1],size(velocity))]
flag_names=["event1","event2","event3"]
flight_data.heading_deg          =heading_deg          ;
flight_data.pitch_deg            =pitch_deg            ;
flight_data.bank_deg             =bank_deg             ;
flight_data.roll_command         =roll_command         ;
flight_data.pitch_command        =pitch_command        ;
flight_data.angle_of_attack_deg  =angle_of_attack_deg  ;
flight_data.angle_of_sideslip_deg=angle_of_sideslip_deg;
flight_data.fligh_path_angle_deg =fligh_path_angle_deg ;
flight_data.mach                 =mach                 ;
flight_data.altitude_ft          =altitude_ft          ;
flight_data.nz_g                 =nz_g                 ;
airbrake_cmd= act(:, 9);
red_lamp=randi([0,1],size(dr));
green_lamp=randi([0,1],size(dr));
ctrl_roll=roll_command ;
ctrl_pitch=pitch_command;
pilot_roll=roll_command ;
pilot_pitch=pitch_command;
% flight_data.alpha       = randn(1001, 1) * 2; % Angle of Attack
% flight_data.beta        = randn(1001, 1);     % Sideslip
% flight_data.mach        = linspace(0.3, 1.2, 1001)'; % Mach number
% flight_data.nz          = ones(1001, 1) + randn(1001, 1)*0.5; % Load factor (G)
% flight_data.gamma       = sin(linspace(0, 10, 1001))'; % Flight path angle
% flight_data.altitude_ft = linspace(5000, 25000, 1001)';
% flight_data.ias_knots   = linspace(200, 450, 1001)';
flight_data.pos_x       = cumsum(cos(linspace(0, pi, 541))'); % North position
flight_data.pos_y       = cumsum(sin(linspace(0, pi, 541))'); % East position
flight_data.time=t_new;
% 2. Define the plot_config (8x3 Cell Array)
plot_config = {
    % --- PLOTS 1 to 7: { 'fieldname', xline_val, yline_val } ---
    % Use [] if you don't want to draw a static reference line.
    
    'angle_of_attack_deg',       [], 15.0,'alpha';  % Plot 1: AoA. No x-line. Draw a static y-line at 15 deg.
    'mach',        [],  1.0,       [];  % Plot 2: Mach. No x-line. Draw a static y-line at Mach 1.
    'nz_g',          [],  9.0,       [];  % Plot 3: G-Force. Draw a y-line at 9g limit.
    'angle_of_sideslip_deg',        [],   [],       [];  % Plot 4: Sideslip. No reference lines.
    'fligh_path_angle_deg',       [],   [],       [];  % Plot 5: Flight path angle. No reference lines.
    'altitude_ft', [],   [],       [];  % Plot 6: Altitude. No reference lines.
    'mach',   [],  350,       [];  % Plot 7: Airspeed. Draw a y-line at 350 knots limit.
    
    % --- PLOT 8: { 'x_fieldname', 'y_fieldname', 'color_fieldname' } ---
    % This handles the 2D top-down map view (Plot 8).
    
    'pos_x', 'pos_y', 'altitude_ft' ,       [] % X-axis, Y-axis, and what variable controls the colorbar
}
indx=1:size(flight_data.nz_g,1)
 isave_movie=1
frame_time=1
movie_file_name='b'
%% Run aircraft_3d_animation function
% -------------------------------------------------------------------------
  aircraft_3d_animation(  model_info_file, ...         
    flight_data, ...            % Struct containing ALL flight data arrays (see comments)
    indx, ...                   % Array of indices to simulate (e.g., 100:5000). Use [] for full flight.
    plot_config, ...            % 8x3 Cell array configuring the 8 dynamic plots
    pilot_roll, pilot_pitch, ...% Pilot stick commands
    ctrl_roll, ctrl_pitch, ...  % Controller/Auto stick commands
    throttle_cmd, ...           % Throttle array (e.g. 0-100)
    airbrake_cmd, ...           % Airbrake array (e.g. 0-1)
    red_lamp, green_lamp, ...   % Lamp flags (arrays of 0s and 1s)
    controls_deflection_deg, ...% NxM matrix for surface deflections
        flags, ...     
    flag_names, ...
    frame_sample_time, ...             
    speedx, ...               
    isave_movie, ...           
    movie_file_name)


 


% aircraft_3d_animation(model_info_file,...
%     heading_deg, ...            Heading angle [deg]
%     pitch_deg, ...              Pitch angle [deg]
%     bank_deg, ...               Roll angle [deg]
%     roll_command, ...           Roll  stick command [-1,+1] [-1 -> left,            +1 -> right]
%     pitch_command, ...          Pitch stick command [-1,+1] [-1 -> full-back stick, +1 -> full-fwd stick]
%      rudder_cmd, ...   
%     throttle_cmd, ... 
%     angle_of_attack_deg, ...    AoA [deg]
%     angle_of_sideslip_deg, ...  AoS [deg]
%     fligh_path_angle_deg, ...   Flight path angle [deg]
%     mach, ...                   Mach number
%     altitude_ft, ...            Altitude [ft]
%      velocity, ...               
%  nz_g,  ...                  
%  controls_deflection_deg, ...
%  flags, ...                  
%  flag_names, ...             
%     frame_sample_time, ...      Sample time [sec]
%     speedx, ...                 Reproduction speed
%     isave_movie, ...            Save the movie? 0-1
%     movie_file_name);           % Movie file name