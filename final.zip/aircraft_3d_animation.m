function [] = aircraft_3d_animation(model_mat_file, flight_data, var_map, plot_config, options)           
%% Function Name: aircraft_3d_animation
%
% INPUTS:
%   model_mat_file : Path to 3D model .mat file
%   flight_data    : Struct containing all time-history arrays
%   var_map        : Struct mapping internal names to your flight_data fields
%   plot_config    : 8x4 Cell array configuring the side/map plots
%   options        : Struct with optional settings (indx, speedx, isave, filename, etc)

% Check Matlab version
MatVersion = version('-release');
MatVersion = str2double(MatVersion(1:end-1));
if MatVersion < 2018
    error('MATLAB version not supported [ < 2018 ]');
end

%% 1. Default Configurations & Safe Data Extraction
if nargin < 5, options = struct(); end
if ~isfield(options, 'indx'), options.indx = []; end
if ~isfield(options, 'speedx'), options.speedx = 1.0; end
if ~isfield(options, 'isave_movie'), options.isave_movie = 0; end
if ~isfield(options, 'movie_file_name'), options.movie_file_name = 'animation.mp4'; end
if ~isfield(options, 'frame_time'), options.frame_time = 0.1; end
if ~isfield(options, 'flag_names'), options.flag_names = {'Event1','Event2','Event3'}; end

% Default variable mappings
default_map = struct(...
    'time', 'time', 'heading', 'heading_deg', 'pitch', 'pitch_deg', 'bank', 'bank_deg', ...
    'alpha', 'alpha', 'beta', 'beta', 'pilot_roll', 'pilot_roll', 'pilot_pitch', 'pilot_pitch', ...
    'ctrl_roll', 'ctrl_roll', 'ctrl_pitch', 'ctrl_pitch', 'throttle', 'throttle', ...
    'airbrake', 'airbrake', 'red_lamp', 'red_lamp', 'green_lamp', 'green_lamp', ...
    'controls', 'controls_deflection', 'flags', 'flags');

if nargin < 3 || isempty(var_map), var_map = struct(); end
fnames = fieldnames(default_map);
for i = 1:length(fnames)
    if ~isfield(var_map, fnames{i}), var_map.(fnames{i}) = default_map.(fnames{i}); end
end

% Function to safely extract data, padding with zeros if missing
time_len = length(flight_data.(var_map.time));
safe_get = @(fname, cols) get_flight_data(flight_data, fname, time_len, cols);

% Extract Data
time_arr     = safe_get(var_map.time, 1);
hdg_arr      = safe_get(var_map.heading, 1);
pch_arr      = safe_get(var_map.pitch, 1);
bnk_arr      = safe_get(var_map.bank, 1);
alpha_arr    = safe_get(var_map.alpha, 1);
beta_arr     = safe_get(var_map.beta, 1);
p_roll_arr   = safe_get(var_map.pilot_roll, 1);
p_pitch_arr  = safe_get(var_map.pilot_pitch, 1);
c_roll_arr   = safe_get(var_map.ctrl_roll, 1);
c_pitch_arr  = safe_get(var_map.ctrl_pitch, 1);
thr_arr      = safe_get(var_map.throttle, 1);
brk_arr      = safe_get(var_map.airbrake, 1);
red_arr      = safe_get(var_map.red_lamp, 1);
green_arr    = safe_get(var_map.green_lamp, 1);
ctrls_arr    = safe_get(var_map.controls, 6); % Assumes max 6 control surfaces default
flags_arr    = safe_get(var_map.flags, length(options.flag_names));

% Apply Index Trimming
indx = options.indx;
if isempty(indx), indx = 1:time_len; end

time_arr = time_arr(indx); hdg_arr = hdg_arr(indx); pch_arr = pch_arr(indx);
bnk_arr = bnk_arr(indx); alpha_arr = alpha_arr(indx); beta_arr = beta_arr(indx);
p_roll_arr = p_roll_arr(indx); p_pitch_arr = p_pitch_arr(indx);
c_roll_arr = c_roll_arr(indx); c_pitch_arr = c_pitch_arr(indx);
thr_arr = thr_arr(indx); brk_arr = brk_arr(indx);
red_arr = red_arr(indx); green_arr = green_arr(indx);
ctrls_arr = ctrls_arr(indx, :); flags_arr = flags_arr(indx, :);

% Trim all arrays in the original flight_data struct for the dynamic plotting
all_fd_fields = fieldnames(flight_data);
for i = 1:length(all_fd_fields)
    val = flight_data.(all_fd_fields{i});
    if size(val, 1) >= max(indx)
        flight_data.(all_fd_fields{i}) = val(indx, :);
    elseif size(val, 2) >= max(indx)
        flight_data.(all_fd_fields{i}) = val(:, indx);
    end
end

% Ensure plot_config has at least 4 columns
if size(plot_config, 2) < 4
    for r = 1:size(plot_config, 1), plot_config{r, 4} = ''; end
end

%% 2. Load 3D model
load(model_mat_file, 'Model3D');
AC_DIMENSION = max(max(sqrt(sum(Model3D.Aircraft(1).stl_data.vertices.^2, 2))));
for i=1:length(Model3D.Control)
    AC_DIMENSION = max(AC_DIMENSION, max(max(sqrt(sum(Model3D.Control(i).stl_data.vertices.^2, 2)))));
end

%% 3. Initialize Layout
figure1 = figure('Units', 'normalized', 'Position', [0.05 0.05 0.9 0.8], 'Color', [1 1 1]);
cameratoolbar(figure1, 'Show');
pan(figure1, 'xon'); % Enable horizontal panning by default

% Initialize App Data
setappdata(figure1, 'plot_config', plot_config);
setappdata(figure1, 'config_changed', false);
setappdata(figure1, 'page_start', time_arr(1));
setappdata(figure1, 'window_width', 10);
setappdata(figure1, 'force_page', false);

% --- EXACT USER LAYOUT ---
ax_p1 = axes('Parent',figure1, 'Position',[0.0286,0.7981,0.1582,0.1544]); title('Plot 1');
ax_p3 = axes('Parent',figure1, 'Position',[0.0267,0.5686,0.1582,0.1544]); title('Plot 3');
ax_p5 = axes('Parent',figure1, 'Position',[0.0198,0.3167,0.1623,0.1641]); title('Plot 5');
ax_p7 = axes('Parent',figure1, 'Position',[0.0159,0.0729,0.1678,0.1641]); title('Plot 7');
ax_p2 = axes('Parent',figure1, 'Position',[0.2205,0.7975,0.1582,0.1544]); title('Plot 2');
ax_p4 = axes('Parent',figure1, 'Position',[0.2187,0.5680,0.1582,0.1544]); title('Plot 4');
ax_p6 = axes('Parent',figure1, 'Position',[0.2156,0.3389,0.1587,0.1579]); title('Plot 6');

plots_ax = [ax_p1, ax_p2, ax_p3, ax_p4, ax_p5, ax_p6, ax_p7];

% Build ECG Lines
for k = 1:7, axes(plots_ax(k)); hold on; grid on; end
build_ecg_lines(plots_ax, plot_config); 

h_lines_dyn = cell(1,7);
for k = 1:7
    line_objs = findobj(plots_ax(k), 'Type', 'Line'); 
    h_lines_dyn{k} = flipud(line_objs(~contains(get(line_objs,'Tag'), 'refline'))); 
    
    fnames = strsplit(char(plot_config{k,1}), '/');
    y_min = inf; y_max = -inf;
    for f = 1:length(fnames)
        fname_clean = strtrim(fnames{f});
        if isfield(flight_data, fname_clean)
            curr_y = flight_data.(fname_clean);
            y_min = min(y_min, min(curr_y)); y_max = max(y_max, max(curr_y));
        end
    end
    if isinf(y_min) || y_min == y_max, y_min = y_min - 1; y_max = y_max + 1; end
    ylim(plots_ax(k), [y_min-eps, y_max+eps] + [-0.1 0.1]*(y_max - y_min));
end

% Plot 8 (3D Map with Colored State Line)
ax_p8 = axes('Parent',figure1, 'Position',[0.7260 0.4000 0.2500 0.5479]);
grid(ax_p8,'on'); colorbar(ax_p8,'southoutside'); hold(ax_p8, 'on'); view(ax_p8, 2);

p8_full_x = flight_data.(strtrim(plot_config{8,1}));
p8_full_y = flight_data.(strtrim(plot_config{8,2}));
x_pad = max(0.1, (max(p8_full_x) - min(p8_full_x)) * 0.05);
y_pad = max(0.1, (max(p8_full_y) - min(p8_full_y)) * 0.05);
xlim(ax_p8, [min(p8_full_x) - x_pad, max(p8_full_x) + x_pad]);
ylim(ax_p8, [min(p8_full_y) - y_pad, max(p8_full_y) + y_pad]);

h_p8_surf = surface(ax_p8, [NaN NaN; NaN NaN], [NaN NaN; NaN NaN], [NaN NaN; NaN NaN], [NaN NaN; NaN NaN], ...
    'FaceColor', 'none', 'EdgeColor', 'flat', 'LineWidth', 2);
colormap(ax_p8, lines(7)); clim(ax_p8, [0 6]);

% Sticks & Gauges
ax_pilot = axes('Parent',figure1, 'Position',[0.4265 0.0626 0.1493 0.2213]); title('Pilot Stick');
plot(ax_pilot, [-1 1 1 -1 -1], [-1 -1 1 1 -1], 'k-'); hold(ax_pilot, 'on');
h_pilot_trace = plot(ax_pilot, NaN, NaN, '-', 'Color', [0.5 0.5 0.5], 'LineWidth', 2);
h_pilot_line = plot(ax_pilot, NaN, NaN, 'b-', 'LineWidth', 2);
h_pilot_dot = plot(ax_pilot, NaN, NaN, 'bo', 'MarkerFaceColor', 'b');
plot(ax_pilot, 0, 0, 'ks', 'MarkerFaceColor', 'b'); axis(ax_pilot, [-1 1 -1 1]); grid on;

ax_ctrl = axes('Parent',figure1, 'Position',[0.6098 0.0637 0.1477 0.2113]); title('Controller Stick');
plot(ax_ctrl, [-1 1 1 -1 -1], [-1 -1 1 1 -1], 'k-'); hold(ax_ctrl, 'on');
h_ctrl_trace = plot(ax_ctrl, NaN, NaN, '-', 'Color', [0.5 0.5 0.5], 'LineWidth', 2);
h_ctrl_line = plot(ax_ctrl, NaN, NaN, 'r-', 'LineWidth', 2);
h_ctrl_dot = plot(ax_ctrl, NaN, NaN, 'ro', 'MarkerFaceColor', 'r');
plot(ax_ctrl, 0, 0, 'ks', 'MarkerFaceColor', 'r'); axis(ax_ctrl, [-1 1 -1 1]); grid on;

ax_thr = axes('Parent',figure1, 'Position',[0.3673,0.0413,0.029,0.2332]); title('Thr');
h_thr_patch = patch(ax_thr, [0 1 1 0], [0 0 0 0], 'g'); axis(ax_thr, [0 1 0 100]); set(ax_thr, 'XTick', []); box on;

ax_airbrake = axes('Parent',figure1, 'Position',[0.2144,0.0734,0.0855,0.2163]); title('Airbrake');
h_brk_patch = patch(ax_airbrake, [0 1 1 0], [0 0 0 0], 'c'); axis(ax_airbrake, [0 1 0 1]); set(ax_airbrake, 'XTick', []); box on;

ax_green = axes('Parent',figure1, 'Position',[0.3102 0.0742 0.0376 0.0704]); title('Green');
h_green = patch(ax_green, [0 1 1 0], [0 0 1 1], [0 0.2 0]); axis off;

ax_red = axes('Parent',figure1, 'Position',[0.3121 0.2194 0.0342 0.0704]); title('Red');
h_red = patch(ax_red, [0 1 1 0], [0 0 1 1], [0.2 0 0]); axis off;

% Settings Pane 
pnl_setting = uipanel('Parent', figure1, 'Position', [0.8010 0.0356 0.1610 0.2443], 'Title', 'Settings', 'FontWeight', 'bold');
uicontrol('Parent', pnl_setting, 'Style', 'pushbutton', 'String', 'Load TXT Config', 'Units', 'normalized', 'Position', [0.05 0.75 0.9 0.2], 'Callback', @(~,~) load_txt_cb(figure1));
uicontrol('Parent', pnl_setting, 'Style', 'pushbutton', 'String', 'Save TXT Config', 'Units', 'normalized', 'Position', [0.05 0.50 0.9 0.2], 'Callback', @(~,~) save_txt_cb(figure1));
uicontrol('Parent', pnl_setting, 'Style', 'pushbutton', 'String', 'Screenshot', 'Units', 'normalized', 'Position', [0.05 0.25 0.9 0.2], 'Callback', @(~,~) screenshot_cb(figure1));
uicontrol('Parent', pnl_setting, 'Style', 'pushbutton', 'String', 'Page Right ->', 'Units', 'normalized', 'Position', [0.05 0.0 0.9 0.2], 'Callback', @(~,~) force_page_cb(figure1));

h_flags_text = annotation('textbox', [0.4395,0.3340,0.1260,0.0246], 'String', '', 'LineStyle', 'none', 'HorizontalAlignment', 'center', 'FontSize', 12, 'Color', 'r', 'FontWeight', 'bold', 'Interpreter', 'none');

% 3D Aircraft Setup
ax_anim = axes('Parent',figure1, 'Position',[0.3446,0.3315,0.3898,0.6457]);
axis off; hold on; axis('equal');
AV_hg = hgtransform('Parent', ax_anim);
CONT_hg = gobjects(1,length(Model3D.Control));
for i=1:length(Model3D.Control)
    CONT_hg(i) = hgtransform('Parent', AV_hg, 'tag', Model3D.Control(i).label);
end
euler_hgt(1) = hgtransform('Parent', ax_anim, 'tag', 'OriginAxes');
euler_hgt(2) = hgtransform('Parent', euler_hgt(1), 'tag', 'roll_disc');
euler_hgt(3) = hgtransform('Parent', euler_hgt(1), 'tag', 'pitch_disc');
euler_hgt(4) = hgtransform('Parent', euler_hgt(1), 'tag', 'heading_disc');
euler_hgt(5) = hgtransform('Parent', euler_hgt(2), 'tag', 'roll_line');
euler_hgt(6) = hgtransform('Parent', euler_hgt(3), 'tag', 'pitch_line');
euler_hgt(7) = hgtransform('Parent', euler_hgt(4), 'tag', 'heading_line');

for i = 1:length(Model3D.Aircraft)
    patch(Model3D.Aircraft(i).stl_data, 'FaceColor', Model3D.Aircraft(i).color, 'EdgeColor', 'none', 'FaceLighting', 'gouraud', 'AmbientStrength', 0.15, 'Parent', AV_hg);
end
for i=1:length(Model3D.Control)
    patch(Model3D.Control(i).stl_data, 'FaceColor', Model3D.Control(i).color, 'EdgeColor', 'none', 'FaceLighting', 'gouraud', 'AmbientStrength', 0.15, 'Parent', CONT_hg(i));
end

R = AC_DIMENSION;
phi_rad = (-pi:pi/36:pi)'; D1 = [sin(phi_rad) cos(phi_rad) zeros(size(phi_rad))];
plot3(R * D1(:,1), R * D1(:,2), R * D1(:,3), 'Color', 'b', 'Parent', euler_hgt(4));
plot3(R * D1(:,2), R * D1(:,3), R * D1(:,1), 'Color', [0, 0.8, 0], 'Parent', euler_hgt(3));
plot3(R * D1(:,3), R * D1(:,1), R * D1(:,2), 'Color', 'r', 'Parent', euler_hgt(2));
plot3([-R, R], [ 0, 0], [0, 0], 'b-', 'parent', euler_hgt(7));
plot3([-R, R], [ 0, 0], [0 ,0], 'g-', 'parent', euler_hgt(6));
plot3([ 0, 0], [-R, R], [0, 0], 'r-', 'parent', euler_hgt(5));

hdle_text_t = text(0, 0, AC_DIMENSION * 2.2, 't=  0 sec', 'Color','k', 'FontSize',16, 'FontWeight', 'bold', 'HorizontalAlignment', 'center', 'Parent', ax_anim);
hdle_text_psi = text(0.45*AC_DIMENSION*1.5, 0.55*AC_DIMENSION*1.5, 0.55*AC_DIMENSION*1.5, '', 'Color','m', 'FontSize',13, 'FontWeight','bold', 'Parent',ax_anim);
hdle_text_th  = text(0.45*AC_DIMENSION*1.5, 0.55*AC_DIMENSION*1.5, 0.47*AC_DIMENSION*1.5, '', 'Color','m', 'FontSize',13, 'FontWeight','bold', 'Parent',ax_anim);
hdle_text_phi = text(0.45*AC_DIMENSION*1.5, 0.55*AC_DIMENSION*1.5, 0.40*AC_DIMENSION*1.5, '', 'Color','m', 'FontSize',13, 'FontWeight','bold', 'Parent',ax_anim);

axis(ax_anim, [-1, 1, -1, 1, -1, 1] * 2.0 * AC_DIMENSION);
view(ax_anim, [30, 10]); zoom(ax_anim, 2.0); camlight(ax_anim, 'left'); material(ax_anim, 'dull');
X_aer = [0, 0]; Y_aer = [0, 0]; Z_aer = [0, 0];
hdle_aero = plot3(ax_anim, X_aer, Y_aer, Z_aer, 'b-o', 'XDataSource', 'X_aer', 'YDataSource', 'Y_aer', 'ZDataSource', 'Z_aer', 'linewidth', 4);

%% 4. Animation Loop
if options.isave_movie == 1
    aviobj = VideoWriter(options.movie_file_name, 'MPEG-4');
    aviobj.Quality = 100; aviobj.FrameRate = 1/options.frame_time; open(aviobj);
end

tic;
for i = 1:length(time_arr)
    t_sec = time_arr(i);
    
    % Dynamic Reload of Config mid-flight
    if getappdata(figure1, 'config_changed')
        plot_config = getappdata(figure1, 'plot_config');
        build_ecg_lines(plots_ax, plot_config);
        
        for k = 1:7
            line_objs = findobj(plots_ax(k), 'Type', 'Line'); 
            h_lines_dyn{k} = flipud(line_objs(~contains(get(line_objs,'Tag'), 'refline'))); 
            fnames = strsplit(char(plot_config{k,1}), '/');
            y_min = inf; y_max = -inf;
            for f = 1:length(fnames)
                fname_clean = strtrim(fnames{f});
                if isfield(flight_data, fname_clean)
                    curr_y = flight_data.(fname_clean);
                    y_min = min(y_min, min(curr_y)); y_max = max(y_max, max(curr_y));
                end
            end
            if isinf(y_min) || y_min == y_max, y_min = y_min - 1; y_max = y_max + 1; end
            ylim(plots_ax(k), [y_min-eps, y_max+eps] + [-0.1 0.1]*(y_max - y_min));
        end
        
        p8_full_x = flight_data.(strtrim(plot_config{8,1})); 
        p8_full_y = flight_data.(strtrim(plot_config{8,2}));
        x_pad = max(0.1, (max(p8_full_x) - min(p8_full_x)) * 0.05); 
        y_pad = max(0.1, (max(p8_full_y) - min(p8_full_y)) * 0.05);
        xlim(ax_p8, [min(p8_full_x)-x_pad, max(p8_full_x)+x_pad]); 
        ylim(ax_p8, [min(p8_full_y)-y_pad, max(p8_full_y)+y_pad]);
        
        setappdata(figure1, 'config_changed', false);
    end

    % 1. AIRCRAFT 3D BODY
    hdg = hdg_arr(i); pch = pch_arr(i); bnk = bnk_arr(i);
    M3 = makehgtform('zrotate', -hdg * pi/180); set(euler_hgt(3), 'Matrix', M3);
    M1 = makehgtform('zrotate', -hdg * pi/180); M2 = makehgtform('yrotate', pch * pi/180); set(euler_hgt(2), 'Matrix', M1*M2);
    set(euler_hgt(5), 'Matrix', makehgtform('xrotate', -bnk * pi/180));
    set(euler_hgt(6), 'Matrix', makehgtform('yrotate', pch * pi/180));
    set(euler_hgt(7), 'Matrix', makehgtform('zrotate', -hdg * pi/180));
    set(AV_hg, 'Matrix', M1 * M2 * makehgtform('xrotate', -bnk * pi/180));
    
    for j = 1:length(Model3D.Control)
        if j <= size(ctrls_arr, 2)
            Mt1 = makehgtform('translate', -Model3D.Control(j).rot_point);
            Mr  = makehgtform('axisrotate', Model3D.Control(j).rot_vect, ctrls_arr(i, j) * pi/180);
            Mt2 = makehgtform('translate', Model3D.Control(j).rot_point);
            set(CONT_hg(j), 'Matrix', Mt2 * Mr * Mt1);
        end
    end
    
    Lbh_i = Lbh(hdg, pch, bnk);
    Vaer  = Lbh_i' * Lbw(alpha_arr(i), beta_arr(i)) * [AC_DIMENSION; 0; 0];
    X_aer = [0, -Vaer(1)]; Y_aer = [0, +Vaer(2)]; Z_aer = [0, -Vaer(3)];
    refreshdata(hdle_aero, 'caller');
    
    % 2. TEXT & FLAGS
    set(hdle_text_t, 'String', sprintf('Time = %3.2f sec', t_sec));
    set(hdle_text_psi, 'String', sprintf('\\psi = %2.1f^\\circ', hdg));
    set(hdle_text_th, 'String', sprintf('\\theta = %2.1f^\\circ', pch));
    set(hdle_text_phi, 'String', sprintf('\\phi = %2.1f^\\circ', bnk));

    active_idx = find(flags_arr(i, :));
    if isempty(active_idx), set(h_flags_text, 'String', '');
    else
        act_names = options.flag_names(active_idx); cl = ''; l_arr = {};
        for k = 1:length(act_names)
            if isempty(cl), cl = act_names{k}; else, cl = [cl, '   |   ', act_names{k}]; end
            if length(cl) > 50 && k < length(act_names), l_arr{end+1} = cl; cl = ''; end
        end
        if ~isempty(cl), l_arr{end+1} = cl; end
        set(h_flags_text, 'String', l_arr);
    end
    
    % 3. ECG PLOTS
    t_curr = time_arr(1:i);
    pg_st = getappdata(figure1, 'page_start'); w_wid = getappdata(figure1, 'window_width');
    
    if t_sec > pg_st + w_wid || getappdata(figure1, 'force_page')
        pg_st = t_sec; setappdata(figure1, 'page_start', pg_st); setappdata(figure1, 'force_page', false);
    end
    
    for k = 1:7
        xlim(plots_ax(k), [pg_st, pg_st + w_wid]);
        fnames = strsplit(char(plot_config{k,1}), '/');
        t_raw = ''; if size(plot_config, 2) >= 4, t_raw = strtrim(char(plot_config{k,4})); end
        if isempty(t_raw), tnames = fnames; else, tnames = strsplit(t_raw, '/'); for pad=length(tnames)+1:length(fnames), tnames{pad} = fnames{pad}; end; end
        
        line_objs = h_lines_dyn{k}; 
        
        title_pts = {};
        for f = 1:length(fnames)
            if f <= length(line_objs) && isfield(flight_data, strtrim(fnames{f}))
                y_data = flight_data.(strtrim(fnames{f}))(1:i);
                set(line_objs(f), 'XData', t_curr, 'YData', y_data);
                title_pts{end+1} = sprintf('%s: %.2f', strtrim(tnames{f}), y_data(end));
            end
        end
        title(plots_ax(k), strjoin(title_pts, '  |  '), 'Interpreter', 'none');
    end
    
    % 4. PLOT 8 (Surface)
    if i > 1
        p8x = flight_data.(strtrim(plot_config{8,1}))(1:i); 
        p8y = flight_data.(strtrim(plot_config{8,2}))(1:i); 
        p8z = zeros(1, i); 
        p8c = zeros(1, i);
        if size(plot_config, 2) >= 3 && ~isempty(strtrim(plot_config{8,3})) && isfield(flight_data, strtrim(plot_config{8,3}))
            curr_c = flight_data.(strtrim(plot_config{8,3}))(1:i);
            p8c = curr_c(:)';
        end
        
        X = p8x(:)'; Y = p8y(:)';
        set(h_p8_surf, 'XData', [X;X], 'YData', [Y;Y], 'ZData', [p8z;p8z], 'CData', [p8c;p8c]);
        
        p8_title_raw = '';
        if size(plot_config, 2) >= 4, p8_title_raw = strtrim(char(plot_config{8,4})); end
        if isempty(p8_title_raw), p8_title_raw = sprintf('%s vs %s', plot_config{8,1}, plot_config{8,2}); end
        title(ax_p8, sprintf('%s (X: %.2f | Y: %.2f)', p8_title_raw, p8x(end), p8y(end)), 'Interpreter', 'none');
    end
    
    % 5. STICKS & GAUGES
    set(h_thr_patch, 'YData', [0 0 thr_arr(i) thr_arr(i)]);
    set(h_brk_patch, 'YData', [0 0 brk_arr(i) brk_arr(i)]);
    set(h_pilot_trace, 'XData', p_roll_arr(1:i), 'YData', p_pitch_arr(1:i));
    set(h_pilot_line, 'XData', [0, p_roll_arr(i)], 'YData', [0, p_pitch_arr(i)]);
    set(h_pilot_dot, 'XData', p_roll_arr(i), 'YData', p_pitch_arr(i));
    set(h_ctrl_trace, 'XData', c_roll_arr(1:i), 'YData', c_pitch_arr(1:i));
    set(h_ctrl_line, 'XData', [0, c_roll_arr(i)], 'YData', [0, c_pitch_arr(i)]);
    set(h_ctrl_dot, 'XData', c_roll_arr(i), 'YData', c_pitch_arr(i));
    if green_arr(i) == 1, set(h_green, 'FaceColor', [0 1 0]); else, set(h_green, 'FaceColor', [0 0.2 0]); end
    if red_arr(i) == 1, set(h_red, 'FaceColor', [1 0 0]); else, set(h_red, 'FaceColor', [0.2 0 0]); end
    
    drawnow;
    if t_sec * options.speedx - toc > 0
        pause(t_sec * options.speedx - toc);
    end
    
    if options.isave_movie == 1, writeVideo(aviobj, getframe(figure1)); end
end

if options.isave_movie == 1, close(aviobj); end
end

% -------------------------------------------------------------------------
% LOCAL FUNCTIONS
% -------------------------------------------------------------------------
function val = get_flight_data(data, field_name, expected_len, cols)
    if isfield(data, field_name)
        val = data.(field_name);
    else
        warning('Field "%s" not found. Defaulting to zeros.', field_name);
        val = zeros(expected_len, cols);
    end
end

function build_ecg_lines(axes_arr, config)
    col_map = lines(10);
    for k = 1:7
        cla(axes_arr(k));
        fnames = strsplit(char(config{k,1}), '/');
        if ~isempty(config{k,2})
            xlines = strsplit(char(string(config{k,2})), '/');
            for x=1:length(xlines)
                xval = str2double(strtrim(xlines{x}));
                if ~isnan(xval), xline(axes_arr(k), xval, 'k--', 'Tag', 'refline'); end
            end
        end
        if ~isempty(config{k,3})
            ylines = strsplit(char(string(config{k,3})), '/');
            for y=1:length(ylines)
                yval = str2double(strtrim(ylines{y}));
                if ~isnan(yval), yline(axes_arr(k), yval, 'k--', 'Tag', 'refline'); end
            end
        end
        for f = 1:length(fnames)
            plot(axes_arr(k), NaN, NaN, '-', 'Color', col_map(f,:), 'LineWidth', 1.5, 'Tag', strtrim(fnames{f}));
        end
    end
end

function Lbh = Lbh(hdg, pch, phi)
sps = sind(hdg); cps = cosd(hdg); sth = sind(pch); cth = cosd(pch); sph = sind(phi); cph = cosd(phi);
Lb1 = [1 0 0; 0 cph sph; 0 -sph cph]; L12 = [cth 0 -sth; 0 1 0; sth 0 cth]; L2h = [cps sps 0; -sps cps 0; 0 0 1];
Lbh = Lb1 * L12 * L2h;
end

function Lbw = Lbw(alpha, beta)
sa = sind(alpha); ca = cosd(alpha); sb = sind(beta); cb = cosd(beta);
Lbw = [ca*cb -ca*sb -sa; sb cb 0; sa*cb -sa*sb ca];
end

% -------------------------------------------------------------------------
% UI CALLBACKS (TXT)
% -------------------------------------------------------------------------
function load_txt_cb(fig)
    [f, p] = uigetfile('*.txt', 'Load TXT Config');
    if f ~= 0
        lines_cell = readlines(fullfile(p, f));
        new_config = cell(8, 4);
        for r = 1:min(8, length(lines_cell))
            if strlength(strtrim(lines_cell(r))) == 0, continue; end
            parts = strsplit(lines_cell(r), ';');
            for c = 1:min(4, length(parts))
                new_config{r, c} = strtrim(char(parts(c)));
            end
        end
        for r = 1:8
            for c = 1:4
                if isempty(new_config{r,c}), new_config{r,c} = ''; end
            end
        end
        setappdata(fig, 'plot_config', new_config);
        setappdata(fig, 'config_changed', true);
    end
end

function save_txt_cb(fig)
    pc = getappdata(fig, 'plot_config');
    [f, p] = uiputfile('plot_config.txt', 'Save TXT Config');
    if f ~= 0
        fid = fopen(fullfile(p, f), 'w');
        for r = 1:8
            fprintf(fid, '%s ; %s ; %s ; %s\n', string(pc{r,1}), string(pc{r,2}), string(pc{r,3}), string(pc{r,4}));
        end
        fclose(fid);
    end
end

function force_page_cb(fig)
    setappdata(fig, 'force_page', true);
end

function screenshot_cb(fig)
    filename = sprintf('screenshot_%s.png', datestr(now, 'yyyymmdd_HHMMSS'));
    exportgraphics(fig, filename, 'Resolution', 300);
    disp(['Saved: ', filename]);
end