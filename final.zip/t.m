%% Example script to visualize the aircraft simulation data
% Add the path of the aircraft_3d_animation function
% addpath('../src/');
% path of the *.mat file containing the 3d model information
model_info_file = 'C:\Users\raval\Desktop\New folder (4)\aircraft_3d_animation-main\aircraft_3d_animation-main\3d_models/t.mat';

% Load the simulation data
% load('scissors_maneuver.mat')
% load('breakaway_maneuver.mat')
% load('split_s_maneuver.mat')
load('C:\Users\raval\Desktop\New folder (4)\aircraft_3d_animation-main\aircraft_3d_animation-main\examples\departure.mat')

% Reproduction options
speedx = 1; 
isave_movie = 0;
movie_file_name = '';

% -------------------------------------------------------------------------
% 1. Time Processing & Resampling
% -------------------------------------------------------------------------
frame_sample_time = max(0.02, tout(2)-tout(1));
t_new   = tout(1):frame_sample_time*(speedx):tout(end);
act     = interp1(tout, act, t_new','linear');
stick   = interp1(tout, stick, t_new','linear');
y_new   = interp1(tout, yout, t_new','linear');

% Angle wrapping fixes
y_new(:, 7)  = atan2(interp1(tout, sin(yout(:, 7)), t_new','linear'), interp1(tout, cos(yout(:, 7)), t_new','linear')) * 180 / pi;
y_new(:, 8)  = atan2(interp1(tout, sin(yout(:, 8)), t_new','linear'), interp1(tout, cos(yout(:, 8)), t_new','linear')) * 180 / pi;
y_new(:, 9)  = atan2(interp1(tout, sin(yout(:, 9)), t_new','linear'), interp1(tout, cos(yout(:, 9)), t_new','linear')) * 180 / pi;

% -------------------------------------------------------------------------
% 2. Pack ALL time-varying arrays into the flight_data struct
% -------------------------------------------------------------------------
flight_data = struct();
flight_data.time                  = t_new';

% Euler Angles & Dynamics
flight_data.heading_deg           = y_new(:, 7);
flight_data.pitch_deg             = y_new(:, 8);
flight_data.bank_deg              = y_new(:, 9);
flight_data.angle_of_attack_deg   = y_new(:, 2) * 180 / pi;
flight_data.angle_of_sideslip_deg = y_new(:, 3) * 180 / pi;
flight_data.fligh_path_angle_deg  = y_new(:, 22) * 180 / pi;
flight_data.mach                  = y_new(:, 21);
flight_data.altitude_ft           = -y_new(:, 12);
flight_data.nz_g                  = y_new(:, 19);

% Sticks & Hardware
flight_data.pilot_roll            = -stick(:, 2);
flight_data.pilot_pitch           = -stick(:, 1);
flight_data.ctrl_roll             = -stick(:, 2); % Using same as pilot for example
flight_data.ctrl_pitch            = -stick(:, 1);
flight_data.throttle_cmd          = 130 * rand(size(flight_data.time));
flight_data.airbrake_cmd          = act(:, 9);
flight_data.red_lamp              = randi([0,1], size(flight_data.time));
flight_data.green_lamp            = randi([0,1], size(flight_data.time));

% Control Surfaces
dfp = 0.5 * (act(:, 1) + act(:, 2));
le  = act(:, 9);
dr  = act(:, 8);
df1 = act(:, 6); df2 = act(:, 5); df3 = act(:, 4); df4 = act(:, 3);
lg  = 90 * ones(size(dfp));

flight_data.controls_deflection_deg = [dfp(:), dfp(:), dfp(:), dfp(:), le(:), le(:), dr(:), ...
    0.5*(df1(:)+df2(:)), 0.5*(df3(:)+df4(:)), 0.5*(df1(:)+df2(:)), 0.5*(df3(:)+df4(:)), lg(:), lg(:)];

% Events & Coordinates
flight_data.flags                 = [randi([0,1], size(flight_data.time)), randi([0,1], size(flight_data.time)), randi([0,1], size(flight_data.time))];
flight_data.pos_x                 = cumsum(cos(linspace(0, pi, length(flight_data.time)))'); 
flight_data.pos_y                 = cumsum(sin(linspace(0, pi, length(flight_data.time)))'); 
flight_data.aircraft_state        = randi([0,6], size(flight_data.time)); % For Map Coloring

% -------------------------------------------------------------------------
% 3. Map internal function variables to your exact field names
% -------------------------------------------------------------------------
var_map = struct();
var_map.time        = 'time';
var_map.heading     = 'heading_deg';
var_map.pitch       = 'pitch_deg';
var_map.bank        = 'bank_deg';
var_map.alpha       = 'angle_of_attack_deg';
var_map.beta        = 'angle_of_sideslip_deg';
var_map.pilot_roll  = 'pilot_roll';
var_map.pilot_pitch = 'pilot_pitch';
var_map.ctrl_roll   = 'ctrl_roll';
var_map.ctrl_pitch  = 'ctrl_pitch';
var_map.throttle    = 'throttle_cmd';
var_map.airbrake    = 'airbrake_cmd';
var_map.red_lamp    = 'red_lamp';
var_map.green_lamp  = 'green_lamp';
var_map.controls    = 'controls_deflection_deg';
var_map.flags       = 'flags';

% -------------------------------------------------------------------------
% 4. UI Plot Configuration (8x4 Cell Array)
% Format: {'FieldName(s)', 'Xline_Vals', 'Yline_Vals', 'Custom Titles'}
% Use '/' to plot multiple lines or assign multiple lines to one axis.
% -------------------------------------------------------------------------
plot_config = {
    'angle_of_attack_deg',   '',    '15.0', 'AoA (\alpha)'; 
    'mach',                  '',    '1.0',  'Mach'; 
    'nz_g',                  '',    '9.0',  'Load Factor (g)'; 
    'angle_of_sideslip_deg', '',    '',     '\beta'; 
    'fligh_path_angle_deg',  '',    '',     'Flight Path Angle'; 
    'altitude_ft',           '',    '',     'Altitude (ft)'; 
    'mach',                  '',    '350',  'Airspeed (proxy)'; 
    
    % Plot 8 handles the map mapping: { 'X_field', 'Y_field', 'Color_field', 'Title' }
    'pos_x', 'pos_y', 'aircraft_state', 'Trajectory State'
};

% -------------------------------------------------------------------------
% 5. Options Struct
% -------------------------------------------------------------------------
options = struct();
options.indx            = []; % Empty means simulate full array
options.speedx          = speedx;
options.isave_movie     = isave_movie;
options.movie_file_name = movie_file_name;
options.frame_time      = frame_sample_time;
options.flag_names      = ["Over-G", "Stall Warn", "Weapon Bay"];

% -------------------------------------------------------------------------
% 6. Launch Application!
% -------------------------------------------------------------------------
disp('Starting 3D Animation...');
aircraft_3d_animation(model_info_file, flight_data, var_map, plot_config, options);